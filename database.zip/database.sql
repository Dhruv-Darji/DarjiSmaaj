-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               11.1.0-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for darjisamaj
CREATE DATABASE IF NOT EXISTS `darjisamaj` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
USE `darjisamaj`;

-- Dumping structure for table darjisamaj.administrate
CREATE TABLE IF NOT EXISTS `administrate` (
  `adminId` int(11) NOT NULL AUTO_INCREMENT,
  `UserRoleId` int(11) NOT NULL,
  `AssignedPinCode` int(6) NOT NULL,
  `WhoMade` int(11) NOT NULL,
  `IsActivate` bit(1) NOT NULL DEFAULT b'1',
  `WhenMade` date NOT NULL DEFAULT curdate(),
  PRIMARY KEY (`adminId`),
  KEY `FK_administrate_userroles` (`UserRoleId`),
  KEY `FK_administrate_userroles_2` (`WhoMade`),
  CONSTRAINT `FK_administrate_userroles` FOREIGN KEY (`UserRoleId`) REFERENCES `userroles` (`UserRoleId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_administrate_userroles_2` FOREIGN KEY (`WhoMade`) REFERENCES `userroles` (`UserRoleId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Table will sore the pincode witch are assigned to admin for access.';

-- Dumping data for table darjisamaj.administrate: ~4 rows (approximately)
/*!40000 ALTER TABLE `administrate` DISABLE KEYS */;
INSERT INTO `administrate` (`adminId`, `UserRoleId`, `AssignedPinCode`, `WhoMade`, `IsActivate`, `WhenMade`) VALUES
	(37, 31, 389330, 32, b'1', '2023-08-18'),
	(38, 30, 389330, 32, b'1', '2023-08-18'),
	(39, 33, 394710, 32, b'1', '2023-08-24'),
	(40, 40, 389350, 32, b'0', '2023-08-28');
/*!40000 ALTER TABLE `administrate` ENABLE KEYS */;

-- Dumping structure for table darjisamaj.profilecart
CREATE TABLE IF NOT EXISTS `profilecart` (
  `ProfileCartId` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` int(11) NOT NULL,
  `ProfileId` int(11) NOT NULL,
  `IsInCart` bit(1) NOT NULL DEFAULT b'0',
  `When_ProfileCartId_Made` date NOT NULL DEFAULT curdate(),
  PRIMARY KEY (`ProfileCartId`),
  KEY `FK_profilecart_users` (`UserId`),
  KEY `FK_profilecart_profiles` (`ProfileId`),
  CONSTRAINT `FK_profilecart_profiles` FOREIGN KEY (`ProfileId`) REFERENCES `profiles` (`ProfileId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_profilecart_users` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='This Table will store the profiles which user want to store in the cart.';

-- Dumping data for table darjisamaj.profilecart: ~3 rows (approximately)
/*!40000 ALTER TABLE `profilecart` DISABLE KEYS */;
INSERT INTO `profilecart` (`ProfileCartId`, `UserId`, `ProfileId`, `IsInCart`, `When_ProfileCartId_Made`) VALUES
	(4, 56, 36, b'1', '2023-09-01'),
	(12, 56, 37, b'1', '2023-09-01'),
	(18, 56, 38, b'1', '2023-09-01');
/*!40000 ALTER TABLE `profilecart` ENABLE KEYS */;

-- Dumping structure for table darjisamaj.profiles
CREATE TABLE IF NOT EXISTS `profiles` (
  `ProfileId` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` int(11) NOT NULL,
  `WhoHandle` int(11) NOT NULL,
  `ApprovedStatus` varchar(50) NOT NULL,
  `P_WhenMade` date NOT NULL DEFAULT curdate(),
  `P_SurName` varchar(50) NOT NULL,
  `P_MiddleName` varchar(50) NOT NULL,
  `P_FatherName` varchar(50) NOT NULL,
  `P_MotherName` varchar(50) NOT NULL,
  `P_Gender` varchar(50) NOT NULL,
  `P_DOB` date NOT NULL,
  `P_Email` varchar(50) NOT NULL,
  `LivingWithFamily` varchar(50) NOT NULL,
  `Discription` text NOT NULL,
  `HigherEducation` varchar(50) NOT NULL,
  `EmloyeeIn` varchar(50) NOT NULL,
  `AnnualIncome` varchar(50) NOT NULL,
  `ResumeFilePath` varchar(250) DEFAULT NULL,
  `ProfileImagePath` varchar(250) NOT NULL,
  `BiodataFilePath` varchar(250) NOT NULL,
  PRIMARY KEY (`ProfileId`),
  KEY `fk_profiles_users` (`UserId`),
  KEY `FK_profiles_userroles` (`WhoHandle`),
  CONSTRAINT `FK_profiles_userroles` FOREIGN KEY (`WhoHandle`) REFERENCES `userroles` (`UserRoleId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_profiles_users` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='This is the table where all data of profiles will be stored ';

-- Dumping data for table darjisamaj.profiles: ~6 rows (approximately)
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
INSERT INTO `profiles` (`ProfileId`, `UserId`, `WhoHandle`, `ApprovedStatus`, `P_WhenMade`, `P_SurName`, `P_MiddleName`, `P_FatherName`, `P_MotherName`, `P_Gender`, `P_DOB`, `P_Email`, `LivingWithFamily`, `Discription`, `HigherEducation`, `EmloyeeIn`, `AnnualIncome`, `ResumeFilePath`, `ProfileImagePath`, `BiodataFilePath`) VALUES
	(36, 56, 31, 'Accepted', '2003-07-12', 'Darji', 'Dhruv', 'Snehalkumar', 'Raginiben', 'Male', '2003-07-12', 'dhruv@gmail.com', 'Yes', '"I am a confident and dedicated individual with a Bachelor\'s degree in Computer Science and Engineering. Currently, I am thriving as a Software Engineer in a reputable multinational corporation, where I contribute to innovative projects and enjoy a rewarding professional journey. Alongside my work, I embrace an active lifestyle through regular workouts and a passion for sports. Exploring new places fuels my curiosity, while honesty, integrity, and effective communication shape my approach to life."', 'Graduate', 'Student', '6-8 Lakh', NULL, 'Files\\Uploads\\profileFile\\profileFile---36', 'Files\\Uploads\\biodataFile\\biodataFile---36'),
	(37, 56, 31, 'Accepted', '2003-07-12', 'Darji', 'Dhruv', 'Snehalkumar', 'Raginiben', 'Male', '2003-07-12', 'dhruv@gmail.com', 'Yes', '"I am a confident and dedicated individual with a Bachelor\'s degree in Computer Science and Engineering. Currently, I am thriving as a Software Engineer in a reputable multinational corporation, where I contribute to innovative projects and enjoy a rewarding professional journey. Alongside my work, I embrace an active lifestyle through regular workouts and a passion for sports. Exploring new places fuels my curiosity, while honesty, integrity, and effective communication shape my approach to life."', 'Graduate', 'Student', 'No Income', NULL, 'Files\\Uploads\\profileFile\\profileFile---37', 'Files\\Uploads\\biodataFile\\biodataFile---37'),
	(38, 56, 31, 'Accepted', '2023-08-24', 'Darji', 'Gaurav', 'Snehalkumar', 'RaginiBen', 'Female', '1996-04-13', 'gaurav@gmail.com', 'Yes', '"I am a confident and dedicated individual with a Bachelor\'s degree in Computer Science and Engineering. Currently, I am thriving as a Software Engineer in a reputable multinational corporation, where I contribute to innovative projects and enjoy a rewarding professional journey. Alongside my work, I embrace an active lifestyle through regular workouts and a passion for sports. Exploring new places fuels my curiosity, while honesty, integrity, and effective communication shape my approach to life."', 'Post Graduate', 'Private', '4-6 Lakh', NULL, 'Files\\Uploads\\profileFile\\profileFile---38', 'Files\\Uploads\\biodataFile\\biodataFile---38'),
	(39, 56, 31, 'Accepted', '2023-08-24', 'Darji', 'Maukshik', 'HariharBhai', 'BhavnaBen', 'Female', '2023-08-09', 'picku@gmail.com', 'Yes', '"I am a confident and dedicated individual with a Bachelor\'s degree in Computer Science and Engineering. Currently, I am thriving as a Software Engineer in a reputable multinational corporation, where I contribute to innovative projects and enjoy a rewarding professional journey. Alongside my work, I embrace an active lifestyle through regular workouts and a passion for sports. Exploring new places fuels my curiosity, while honesty, integrity, and effective communication shape my approach to life."', 'Post Graduate', 'Private', '6-8 Lakh', NULL, 'Files\\Uploads\\profileFile\\profileFile---39', 'Files\\Uploads\\biodataFile\\biodataFile---39'),
	(40, 61, 31, 'Accepted', '2023-08-28', 'Darji', 'Smit', 'YogeshKumar', 'Chandrbhaga', 'Male', '1998-03-26', 'smit@gmail.com', 'Yes', 'This is just test', 'Diploma', 'Private', '2-4 Lakh', NULL, 'Files\\Uploads\\profileFile\\profileFile---40', 'Files\\Uploads\\biodataFile\\biodataFile---40'),
	(41, 56, 31, 'Accepted', '2023-08-28', 'darji', 'test', 'test', 'test', 'Female', '2023-08-01', 'pic@gmail.com', 'Yes', 'ahdfkjahdkjfhkad', 'SSC', 'Private', '4-6 Lakh', NULL, 'Files\\Uploads\\profileFile\\profileFile---41', 'Files\\Uploads\\biodataFile\\biodataFile---41');
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;

-- Dumping structure for table darjisamaj.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `RoleId` int(11) NOT NULL AUTO_INCREMENT,
  `RoleName` varchar(255) NOT NULL,
  PRIMARY KEY (`RoleId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table darjisamaj.roles: ~4 rows (approximately)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`RoleId`, `RoleName`) VALUES
	(1, 'SuperAdmin'),
	(2, 'DistrictAdmin'),
	(3, 'Admin'),
	(4, 'AuthUser');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Dumping structure for table darjisamaj.userroles
CREATE TABLE IF NOT EXISTS `userroles` (
  `UserRoleId` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` int(11) NOT NULL,
  `RoleId` int(11) NOT NULL,
  PRIMARY KEY (`UserRoleId`),
  KEY `RoleId` (`RoleId`),
  KEY `userroles_ibfk_1` (`UserId`),
  CONSTRAINT `userroles_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE,
  CONSTRAINT `userroles_ibfk_2` FOREIGN KEY (`RoleId`) REFERENCES `roles` (`RoleId`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table darjisamaj.userroles: ~6 rows (approximately)
/*!40000 ALTER TABLE `userroles` DISABLE KEYS */;
INSERT INTO `userroles` (`UserRoleId`, `UserId`, `RoleId`) VALUES
	(30, 51, 3),
	(31, 52, 2),
	(32, 53, 1),
	(33, 54, 2),
	(35, 56, 4),
	(40, 61, 4);
/*!40000 ALTER TABLE `userroles` ENABLE KEYS */;

-- Dumping structure for table darjisamaj.users
CREATE TABLE IF NOT EXISTS `users` (
  `UserId` int(10) NOT NULL AUTO_INCREMENT,
  `SurName` varchar(50) NOT NULL,
  `MiddleName` varchar(50) NOT NULL,
  `FatherName` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  `MobileNumber` bigint(20) NOT NULL DEFAULT 0,
  `Email` varchar(50) NOT NULL,
  `Address` varchar(250) NOT NULL,
  `PinCode` int(6) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Pargana` varchar(50) NOT NULL,
  `Village` varchar(50) NOT NULL,
  `Native` varchar(50) NOT NULL,
  `ProfilePath` varchar(250) NOT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumping data for table darjisamaj.users: ~6 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`UserId`, `SurName`, `MiddleName`, `FatherName`, `DOB`, `MobileNumber`, `Email`, `Address`, `PinCode`, `Password`, `Gender`, `Pargana`, `Village`, `Native`, `ProfilePath`) VALUES
	(51, 'test', 'test', 'test', '2023-07-10', 9408858246, 'admin@gmail.com', 'test', 389330, '$2b$10$NArP8qpuvGC/H9ffvZEiRuyRmNgQBcd9dgXStLFWi7z8JkGKVGzoO', 'Male', 'test', 'test', 'test', 'Files\\Profiles\\profileImage---51'),
	(52, 'test', 'test', 'test', '2023-07-10', 9408858246, 'dadmin@gmail.com', 'test', 389330, '$2b$10$G7937eaopC09nLJHlVsk3O3AXSIg3IlrgimrISuoLVJoNSDmhFgpC', 'Male', 'test', 'test', 'test', 'Files\\Profiles\\profileImage---52'),
	(53, 'test', 'test', 'test', '2023-07-24', 9408858246, 'sadmin@gmail.com', 'test', 123456, '$2b$10$.cc9TQg4pqpIs43o.MdXXeI3Dvq2oRQ.d.Zbu4PkAqZAhzKL4oTeC', 'Male', 'test', 'test', 'test', 'Files\\Profiles\\profileImage---53'),
	(54, 'Darji', 'Snehal', 'Krushnkant', '2023-08-01', 9408858246, 'snehal@gmail.com', 'Kalol', 394710, '$2b$10$7ZesP2NQgyNfI1SJdhIhGevPMUxbEUfrm0Ce95Ac9itcDal.wtRXW', 'Male', '36', 'Kalol', 'Vejalpur', 'Files\\Profiles\\profileImage---54'),
	(56, 'Darji', 'Dhruv', 'Snehalkumar', '2003-07-12', 9408858246, 'test@gmail.com', '2 Paramba kalol', 389340, '$2b$10$yM29weP30RDU0tUsxs6iT.M5Byz3XlCngFyA/h7VH/L6OgCVp8MxS', 'Male', '9', 'Kalol', 'Vejalpur', 'Files\\Profiles\\profileImage---56'),
	(61, 'Darji', 'Smit', 'YogeshBhai', '1998-03-26', 9909496207, 'smit@gmail.com', 'Arad', 389350, '$2b$10$X4nkcMeZyzvKjGhckhARAOZtZDGOIMEIsWzWJHINuvKcV4P891QPS', 'Male', '36', 'Arad', 'Arad', 'Files\\Profiles\\profileImage---61');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for trigger darjisamaj.update_administrate_is_active
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER update_administrate_is_active
AFTER UPDATE ON userroles
FOR EACH ROW
BEGIN
    IF NEW.RoleId = 2 OR NEW.RoleId = 3 THEN
        UPDATE administrate
        SET IsActivate = 1
        WHERE UserRoleId = NEW.UserRoleId;
    ELSE
        UPDATE administrate
        SET IsActivate = 0
        WHERE UserRoleId = NEW.UserRoleId;
    END IF;
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
